import React, {Component} from 'react';
import Root from './src';
import NavigationService from './src/config/NavigationService';
import {Provider} from 'react-redux';
import {StatusBar} from 'react-native';
import {store} from './src/redux';
class App extends Component {
  render() {
    return (
      <Provider store={store}>
        <StatusBar
          translucent={true}
          backgroundColor="transparent"
          barStyle="light-content"
        />
        <Root
          ref={navigatorRef => {
            NavigationService.setTopLevelNavigator(navigatorRef);
          }}
        />
      </Provider>
    );
  }
}

export default App;
