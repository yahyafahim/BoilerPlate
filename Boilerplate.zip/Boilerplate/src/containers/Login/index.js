import React, {Component} from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  TextInput,
  Dimensions,
} from 'react-native';
import Colors from '../../config/colors';
const {height, width} = Dimensions.get('screen');

class App extends Component {
  state = {
    email: '',
    focused: false,
    error: false,
  };
  render() {
    const {email, focused, error} = this.state;
    return (
      <View
        style={{
          flex: 1,
          zindex: 99,
          paddingHorizontal: 40,
          backgroundColor: Colors.backgroundColor,
        }}></View>
    );
  }
}

export default App;
