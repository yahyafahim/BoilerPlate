// import TabbarComp from './TabbarComp'
import {createAppContainer, createSwitchNavigator} from 'react-navigation';
import {createStackNavigator} from 'react-navigation-stack';
// import { createBottomTabNavigator } from 'react-navigation-tabs';

//Screens
import {Login} from './containers';

const AuthStack = createStackNavigator(
  {
    Login: {screen: Login},
  },

  {
    initialRouteName: 'Login',
    headerMode: 'none',
  },
);

// const HomeStack = createStackNavigator(
//   {
//     Home: {screen: Home},
//   },

//   {
//     initialRouteName: 'Home',
//     headerMode: 'none',
//   },
// );

// const AppStack = createBottomTabNavigator(
//   {
//     Explorer: ExploreStack,
//     Recherche: SearchStack,
//     Moi: ParentsStack,
//     Telechargements: DownloadsStack,
//     Notifications: {screen: Empty},
//   },

//   {
//     initialRouteName: 'Explorer',
//     tabBarComponent:(props)=><TabbarComp  {...props}/>,
//     headerMode: 'none',
//   },
// );

const RootStack = createAppContainer(
  createSwitchNavigator(
    {
      Auth: AuthStack,
      // Home: HomeStack,
      // App: AppStack,
      // SignUpExtra: SignUpExtra,
      // AddChildStack: AddChildStack,
    },
    {
      initialRouteName: 'Auth',
    },
  ),
);

export default RootStack;
