const Colors = {
  backgroundColor: '#F8F9FD',
  Border: '#1D1D26',
  Button: '#E9446A',
  WhiteOpacity: opacity => `rgba(255, 255, 255, ${opacity})`,
  Opacity: opacity => `rgba(0, 0, 0, ${opacity})`,
  Transparent: 'transparent',
  Black: '#000',
  White: '#fff',
  Pink: '#F1668D',
  Purple: '#C34ADC',
  Green: '#13D38E',
  Yellow: '#FFD337',
  Orange: '#FB864A',
  Brown: '#3F2B39',
  Red: 'red',
};
export default Colors;
